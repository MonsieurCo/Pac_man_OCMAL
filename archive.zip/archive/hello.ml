
let rec affiche_hello () =
Unix.sleep 2;
print_string "hello" ; print_newline(); affiche_hello()
let _ = Thread.create affiche_hello ()
let () = (* thread principal *) let s = read_line () in print_string s
